export const LOGGING_CONFIG = {
  enabled: true,
  endpointUrl: "https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec",
  apiKey: "replace-with-the-workflow-shared-key",

  uploadIntervalMinutes: 15,
  maxBatchEvents: 200,
  maxBatchBytes: 500_000,

  softStorageLimitBytes: 5_000_000,
  pruneInfoAtBytes: 7_000_000,
  pruneWarningAtBytes: 8_000_000,
  emergencyLimitBytes: 9_000_000,

  normalRetentionDays: 7,
  warningRetentionDays: 14,
  errorRetentionDays: 30,

  abandonedSessionMinutes: 30,
  diagnosticsEnabled: false
};
