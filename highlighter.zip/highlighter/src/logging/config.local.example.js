export const LOGGING_CONFIG = {
  endpointUrl: "https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec",
  apiKey: "replace-with-the-workflow-shared-key"
};
